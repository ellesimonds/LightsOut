Name: Elle Simonds

--UI:
The ConstraintLayout with one TextView is found on lines 9-18 of the activity_main.xml of the layout folder
of the res folder inside of the app folder under the section titles Android.
The nine buttons can be found below this code in the same xml from lines 34-50.
--Code: 
